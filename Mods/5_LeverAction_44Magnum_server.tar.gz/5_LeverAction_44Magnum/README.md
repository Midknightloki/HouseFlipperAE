# Lever Action Rifle - .44 Magnum

## Overview

Converts the lever action rifle from 7.62mm to .44 Magnum ammunition and enables the shotgun tube magazine extender to be installed on the weapon.

## Changes

### Ammunition Type
- **Before**: ammo762mmBulletBall, ammo762mmBulletHP, ammo762mmBulletAP (7.62mm)
- **After**: ammo44MagnumBulletBall, ammo44MagnumBulletHP, ammo44MagnumBulletAP (.44 Magnum)

### Magazine Compatibility
- Adds `modGunShotgunTubeExtenderMagazine` tag to enable tube magazine extender installation
- Without increasing base magazine size, the tube extender adds ~2-3 extra shots
- Users can manually adjust magazine size for different capacities

## Rationale

Classic lever action rifles historically used .44 Magnum or similar handgun calibers, making this more thematically appropriate than 7.62mm rifle rounds. The tube magazine design is more compatible with magnum handgun cartridges than with pointed rifle rounds.

## Compatibility

- **7 Days to Die Version**: 2.5 Survival Revival
- **Server/Client**: Both (server-only recommended for consistency)
- **Multiplayer**: Yes, all players need the mod for proper synchronization
- **Existing Worlds**: Compatible (players will use existing rifle stats)

## Installation

1. Download/extract to `Mods/` folder
2. Load order: Place before content mods (prefix `5_` ensures proper load order)
3. Start game or restart server

## Testing

- Verify lever action rifle appears in game
- Check ammunition type in inventory (should show .44 Magnum variants)
- Test tube magazine extender can be installed
- Verify weapon fires correctly

## Notes

- This is a pure XML modlet with no code dependencies
- Load order placement: `5_` prefix loads after core patches but before content mods
- Combines perfectly with other weapon mods that don't modify lever action rifle
- For server deployment: Will sync to all clients automatically

## References

- Steam Discussion: https://steamcommunity.com/app/251570/discussions/5/3184614758378802222/
- Based on community-tested XML changes confirmed to work in 7D2D 2.5
