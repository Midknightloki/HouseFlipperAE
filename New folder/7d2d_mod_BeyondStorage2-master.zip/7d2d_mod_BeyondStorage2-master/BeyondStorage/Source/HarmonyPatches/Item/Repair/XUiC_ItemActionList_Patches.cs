﻿using System.Linq;
using BeyondStorage.Scripts.Game.Item;
using HarmonyLib;

namespace BeyondStorage.HarmonyPatches.Item;

[HarmonyPatch(typeof(XUiC_ItemActionList))]
internal static class XUiCItemActionListPatches
{
    // Used For:
    //      Item Repair (tracks item action list visibility)
    [HarmonyPostfix]
    [HarmonyPatch(nameof(XUiC_ItemActionList.Init))]
#if DEBUG
    [HarmonyDebug]
#endif
    private static void XUiC_ItemActionList_Init_Postfix(XUiC_ItemActionList __instance)
    {
        __instance.OnVisiblity += ActionList_VisibilityChanged;
    }

    // Capture when the visibility of the Action List is changed
    private static void ActionList_VisibilityChanged(XUiController _sender, bool _visible)
    {
        ItemRepair.ActionListVisible = _visible;
    }

    // Used For:
    //      Item Repair (captures if item actions list contains repairing)
    [HarmonyPostfix]
    [HarmonyPatch(nameof(XUiC_ItemActionList.SetCraftingActionList))]
#if DEBUG
    [HarmonyDebug]
#endif
    private static void XUiC_ItemActionList_SetCraftingActionList_Postfix(XUiC_ItemActionList __instance)
    {
        ActionList_UpdateVisibleActions(__instance);
    }

    // Used For:
    //      Item Repair (captures if item actions list contains repairing)
    [HarmonyPostfix]
    [HarmonyPatch(nameof(XUiC_ItemActionList.SetServiceActionList))]
#if DEBUG
    [HarmonyDebug]
#endif
    private static void XUiC_ItemActionList_SetServiceActionList_Postfix(XUiC_ItemActionList __instance)
    {
        ActionList_UpdateVisibleActions(__instance);
    }

    internal static void ActionList_UpdateVisibleActions(XUiC_ItemActionList itemActionList)
    {
        ItemRepair.RepairActionShown = ActionList_HasRepair(itemActionList);
    }

    // Check if the list of actions contains Repair
    private static bool ActionList_HasRepair(XUiC_ItemActionList itemActionList)
    {
        return itemActionList.itemActionEntries.OfType<ItemActionEntryRepair>().Any();
    }
}